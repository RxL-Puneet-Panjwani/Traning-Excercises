import java.util.*;

public class LRUCache {
    private Deque<Integer> q;
    private HashSet<Integer> h;
    private final int cSize;

    LRUCache(int winSize){
        q = new LinkedList<>();
        h = new HashSet<>();
        cSize = winSize;
    }
    public void refer(int page){
        if(!h.contains(page)){
            if(q.size()==cSize){
                int last = q.removeLast();
                h.remove(last);
            }
        }
        else{
            q.remove(page);
        }
        q.push(page);
        h.add(page);
    }
    public void display() {
        Iterator<Integer> itr = q.iterator();
        while (itr.hasNext()) {
            System.out.print(itr.next() + " ");
        }
    }
    public static void main(String[] args) {
        LRUCache cache = new LRUCache(3);
        cache.refer(1);
        cache.refer(2);
        cache.refer(3);
        cache.refer(4);
        cache.refer(1);
        cache.refer(2);
        cache.refer(5);
        cache.refer(2);
        cache.refer(1);
        cache.refer(2);
        cache.refer(3);
        cache.refer(4);
        cache.refer(5);
        cache.display();
    }
}
