/**
 *  Time complexity of the algorithm is m+n.
 *  where m and n are the sizes of array 1 and 2 respectively.
 */

import java.util.*;

public class FindCommon {
    ArrayList<Integer> l1 = new ArrayList<>(){
        {   add(2);
            add(4);
            add(1);
            add(56);
            add(3);
        }
    };
    ArrayList<Integer> l2 = new ArrayList<>(){
        {   add(56);
            add(8);
            add(2);
            add(4);
            add(3);
        }
    };

    public void comp(ArrayList<Integer> l1,ArrayList<Integer> l2){
        Set<Integer> s = new HashSet<>(l1);
        ArrayList<Integer> res =new ArrayList<>();
        for(int a: l2){
            if(s.contains(a)){
                res.add(a);
            }
        }
        System.out.println(res);
    }
    public static void main(String[] args){
        FindCommon a = new FindCommon();
        a.comp(a.l1,a.l2);
    }
}
