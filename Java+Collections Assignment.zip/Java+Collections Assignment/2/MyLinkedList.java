import java.lang.invoke.MutableCallSite;

public class MyLinkedList {
    private Node head;
    private Node tail;

    public void add(int value){
        Node node = new Node();
        node.data = value;
        node.link = null;
        if (head == null){
            head = node;
        }
        else{
            tail.link=node;
        }
        tail=node;
    }
    public int delete(){
        if(head == null){
            System.out.println("Can not delete, linked list is empty");
        }
        else{
            int x = tail.data;
            Node t = head;
            while(t.link != tail){
                t=t.link;
            }
            t.link=null;
            return x;
        }
        return 0;
    }
    public void update(int in, int val){
        Node t = head;
        for(int i=0;i<in;i++){
            t=t.link;
        }
        t.data=val;
    }
    public void get(int x){
        if(head == null){
            System.out.println("Linked list is empty");
        }
        else {
            Node t = head;
            for(int i=0;i<x;i++){
                t=t.link;
            }
            System.out.println(t.data);
        }
    }
    public static void main(String[] args) {

    }
}
