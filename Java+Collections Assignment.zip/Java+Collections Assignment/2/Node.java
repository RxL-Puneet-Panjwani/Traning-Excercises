public class Node {
    int data;
    Node link;
}
