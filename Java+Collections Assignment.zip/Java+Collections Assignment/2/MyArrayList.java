import java.lang.management.MemoryType;

public class MyArrayList {
 private int[] data;
 private int cap = 0;
 private int len = -1;

 public MyArrayList(int cap){
  this.cap = cap-1;
  data = new int[cap-1];
 }
 private void newArr(){
  int[] t = new int[(int) (this.cap*1.5)];
  for(int i = 0; i<=len;i++){
   t[i]=data[i];
  }
  this.cap=(int)(cap*1.5);
  this.data = t;
 }

 public void add(int value){
  if(this.len+1>=(this.cap+1)*0.75){
    newArr();
  }
 this.data[++len]=value;
 }

 public void delete(int value){
  int i=0;
  for(i=0;i<=len;i++){
   if(this.data[i]==value) break;
  }
  int j=0;
  for(j=i+1;j<=len;j++){
   this.data[j-1]=this.data[j];
  }
  if(i!=len+1) this.len--;
  else System.out.println(value +" not found.");
 }

 public void update(int ind,int value){
  this.data[ind] = value;
 }

 public int get(int ind){
  return this.data[ind];
 }
 public String toString(){
  StringBuilder res = new StringBuilder();
  for(int i=0;i<=len;i++){
   res.append(this.data[i]).append(" ");
  }
  return res.toString();
 }

 public static void main(String[] args){
 }
}