import java.util.LinkedList;

public class MyQueue {

    private LinkedList<Integer> data;
    private int front = -1;
    private int back = - 1;
    private int count = 0;

    public MyQueue(){
        data = new LinkedList<>();
    }
    public void add(int value){
        if(count == 0){
            data.add(value);
            front++;back++;count++;
        }
        else{
            data.add(value);
            back++;count++;
        }
    }
    public int delete(){
        if(count == 0){
            System.out.println("Can not delete, queue is empty");
        }
        else{
            int x = data.get(front);
            data.remove(front);
            count--;
            return x;
        }
        return 0;
    }
    public void getFront(){
        if(count == 0){
            System.out.println("Queue is empty");
        }
        else
            System.out.println("Queue Front = " + data.get(front));
    }
    public static void main(String[] args) {
    }
}
