import java.util.Vector;

public class MyStack {

    private Vector<Integer> data;
    private int top;

    public MyStack(){
        data = new Vector<>();
        top = -1;
    }
    public MyStack(int size){
        data = new Vector<>(size);
        top = -1;
    }
    public void add(int value){
        data.add(value);
        top++;
    }
    public int delete(){
        if(top==-1){
            System.out.println("Can not delete, stack is empty");
        }
        else{
            int x = data.get(top);
            data.remove(top--);
            return x;
        }
        return 0;
    }
    public void getTop(){
        if(top==-1){
            System.out.println("Stack is empty");
        }
        else
            System.out.println("Stack Top = " + data.get(top));
    }
    public static void main(String[] args) {

    }
}
