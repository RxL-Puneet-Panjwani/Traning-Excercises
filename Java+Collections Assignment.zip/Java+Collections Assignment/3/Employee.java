import java.util.ArrayList;

public class Employee {
    int id;
    String name;
    int age;
    String dept;

    public Employee(int id, String name, int age, String dept){
        this.id = id;
        this.name = name;
        this.age = age;
        this.dept = dept;
    }
    public String toString(){
        return this.id+" "+this.name+" "+this.age+"y "+this.dept;
    }

    public static void main(String[] args){
        ArrayList<Employee> al = new ArrayList<>();
        al.add(new Employee(3,"b",10,"PVD"));
        al.add(new Employee(1,"d",20,"PVR"));
        al.add(new Employee(4,"a",40,"PVS"));
        al.add(new Employee(2,"c",30,"PVQ"));

        al.sort(new SortByIdDesc());
        System.out.println(al.toString());
        al.sort(new SortByNameAsc());
        System.out.println(al.toString());
        al.sort(new SortByAgeDesc());
        System.out.println(al.toString());
    }
}
