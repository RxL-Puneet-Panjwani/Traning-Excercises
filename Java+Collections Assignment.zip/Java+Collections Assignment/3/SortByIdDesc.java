import java.util.Comparator;

public class SortByIdDesc implements Comparator<Employee> {
    public int compare(Employee a, Employee b){
        return b.id-a.id;
    }
}
