import java.util.Comparator;

public class SortByAgeDesc implements Comparator<Employee> {
    public int compare(Employee a, Employee b){
        return b.age-a.age;
    }
}
